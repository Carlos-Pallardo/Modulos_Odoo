from odoo import models, fields

class TypeInvoice(models.Model):
    _name = 'type.invoice'

    name = fields.Char("Nombre")
    code = fields.Char("Código")

    def name_get(self):
        result = []
        for record in self:
            # Personaliza la forma en que se muestra el nombre
            name = f"{record.name} - {record.email}"  # Muestra nombre y correo electrónico del socio
            result.append((record.id, name))
        return result