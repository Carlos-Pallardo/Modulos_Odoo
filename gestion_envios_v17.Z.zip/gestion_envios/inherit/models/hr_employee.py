# -*- coding: utf-8 -*-
from odoo import fields, models, api, _, tools, SUPERUSER_ID
import logging

class Empleados(models.Model):
    _inherit = 'hr.employee'

    asignarenvios = fields.Boolean(string="¿Asignar envíos?",
                                   help="Si se marca abrirá una columna en el apartado Asignación Mensajeros del módulo Gestión de Envíos")

    @api.model
    def create(self, vals):
        if vals.get('user_id'):
            vals.update(self._sync_user(self.env['res.users'].browse(vals['user_id'])))
        objeto = super(Empleados, self).create(vals)
        #self.env['gestiondeenvios.stage'].with_user(SUPERUSER_ID).create({'name': objeto.name,
        #                                          'sequence': objeto.id,
        #                                          'fold': 1,
        #                                          'asignarenvios': objeto.asignarenvios,
        #                                          'mensajerorelacionado': objeto.id})
        return objeto


    def write(self, vals):
        if 'address_home_id' in vals:
            account_id = vals.get('bank_account_id') or self.bank_account_id.id
            if account_id:
                self.env['res.partner.bank'].browse(account_id).partner_id = vals['address_home_id']
        res= super(Empleados, self).write(vals)

        data = self.env['gestiondeenvios.stage'].search([('mensajerorelacionado', '=', self.id)], limit=1)
        logging.info(f"»»»»»» Nombre: {self.name}")
        if data:
            data.write({'asignarenvios': self.asignarenvios})
            data.update_name(f'{self.name}[{self.company_id.name}]')
        else:
            self.env['gestiondeenvios.stage'].create({'name': self.name,
              'sequence': self.id,
              'fold': 1,
              'asignarenvios': self.asignarenvios,
              'mensajerorelacionado': self.id,
            })

        return res


    def unlink(self):
        #resources = self.mapped('resource_id')
        #for res in resources:
        #    res.with_user(SUPERUSER_ID).unlink()
        for rec in self:
            data = self.env['gestiondeenvios.stage'].search([('mensajerorelacionado', '=', rec.id)], limit=1)
            if data:
                data.write({'asignarenvios': False})
        return super(Empleados, self).unlink()        
