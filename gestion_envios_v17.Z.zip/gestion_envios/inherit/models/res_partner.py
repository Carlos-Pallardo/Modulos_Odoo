from odoo import models, fields, api
import logging

class ResPartner(models.Model):
    _inherit = 'res.partner'

    is_customer = fields.Boolean('Es cliente', compute="_compute_is_customer", store=True, readonly=False)
    is_partner = fields.Boolean('Es partner')
    location = fields.Char("Link Maps")
    #ref_invoice = fields.Char(string="Referencia de facturacion",
    #                          help="Añade una referencia para el pago en cada factura")

    def open_location(self):
        if self.location:
            return {
                'type': 'ir.actions.act_url',
                'target': 'new',
                'url': self.location,
            }

    @api.depends('category_id')
    def _compute_is_customer(self):
        for record in self:
            for item in record.category_id:
                logging.info(f"<<<<<<<<<< item: {item.name}")
                if item.name in ["cliente", "Cliente"]:
                    record.is_customer = True
                    if record.parent_id:
                        record.parent_id.is_customer = True
                        for rec in record.parent_id.child_ids:
                            rec.is_customer = True 
                    else:
                        for rec in record.child_ids:
                            rec.is_customer = True