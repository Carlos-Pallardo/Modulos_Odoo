# -*- coding: utf-8 -*-
{
    'name': "Gestión de Envíos",

    'summary': """
        Módulo desarrollado para Mensacom. Odoo 11.
        Actualizado por Itzcoatl Ortega. Odoo17 
    """,

    'description': """
        Módulo desarrollado para Mensacom. Odoo 11
        Módulo actualizado por Itzcoatl Ortega, Odoo17
    """,

    'author': "Enrique Cano",
    'website': "http://www.iddeamweb.com",

    'category': 'Tools',
    'version': '17.0',

    'depends': ['bus', 'mail', 'base', 'contacts', 'sale', 'web_tour', 'hr'],

    # always loaded
    'data': [
        'base/security/security.xml',
        'base/security/ir.model.access.csv',
        'data/ir_sequence.xml',
        'data/default_data.xml',
        'data/poblaciones.xml',
        'base/views/gestiondeenvios_clase.xml',
        'base/views/gestiondeenvios_intermedio.xml',
        'base/views/gestiondeenvios_mercancias.xml',
        'base/views/gestiondeenvios_servicio.xml',
        'base/views/gestiondeenvios_poblaciones.xml',
        'base/views/gestiondeenvios_stage.xml',
        'base/views/type_invoice.xml',
        'base/views/product_invoice.xml',
        'inherit/views/product_template.xml',
        'inherit/views/res_partner.xml',
        'inherit/views/hr_employee.xml',
        'inherit/views/res_settings.xml',
        'inherit/views/sale_order.xml',
        #'inherit/views/custom_styles.xml',
    ],

    'assets': {
        'web.assets_backend': [
            'gestion_envios/static/src/css/main.css',
            'gestion_envios/static/src/js/kanban_view.js',
        ],
    },

    'application': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
