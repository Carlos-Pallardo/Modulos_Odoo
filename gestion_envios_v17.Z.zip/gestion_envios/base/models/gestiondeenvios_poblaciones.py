# -*- coding: utf-8 -*-

from odoo import models, fields, api

class Gestionenviospoblaciones(models.Model):
    _name = "gestiondeenvios.poblaciones"

    @api.depends('poblacion', 'distancia')
    def _computar_nombre(self):
        for record in self:
            record.name = str(record.poblacion) + " [" + str(record.distancia) + "Km]"

    name = fields.Char(string="Población", compute='_computar_nombre', store=True)
    cp = fields.Char(string="Código Postal")
    poblacion = fields.Char(string="Población", required=True)
    distancia = fields.Integer(string="Distancia en Km (Ida y vuelta)", required=True)
    active = fields.Boolean("Activar", default=True)