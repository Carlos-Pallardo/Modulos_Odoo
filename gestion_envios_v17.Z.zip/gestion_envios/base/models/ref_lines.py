from odoo import models, fields, api, SUPERUSER_ID
from odoo.exceptions import UserError
import logging

class RefLines(models.Model):
    _name = 'ref.lines'

    product_id = fields.Many2one('product.product', string='Producto')
    poblacion_id = fields.Many2one('gestiondeenvios.poblaciones', string="Población")
    km_active = fields.Boolean('Activar km')
    km_extra = fields.Integer('Distancia (Km)', related="poblacion_id.distancia", digits=(16, 2), store=True)
    see_manual = fields.Boolean('Ver manualmente?', compute="_compute_see_manual")
    km_manual = fields.Integer('Distancia (Km)', digits=(16,2))
    
    time_active = fields.Boolean('Activar tiempo de espera')
    time_extra = fields.Integer('Tiempo (min)')
    helper_hour_active = fields.Boolean('Activar Hora Ayudante')
    helper_hour = fields.Monetary('Hora ayudante', digits=(16,2))
    linea_active = fields.Boolean('Activar linea manual.')
    linea_manual = fields.Monetary('Linea manual', digits=(16,2))
    unit_active = fields.Boolean('Activar unitario extra')
    unit_extra = fields.Monetary('Unitario extra', digits=(16, 2))
    description = fields.Char("Descripcion")
    inter_id = fields.Many2one('gestiondeenvios.intermedio')

    tax_id = fields.Many2many('account.tax', string='Impuestos')
    price_tax = fields.Monetary('Total impuestos', digits=(16, 2))
    discount = fields.Float(string='Discount (%)', digits=(16,2))

    unit_price = fields.Monetary('Precio unitario', digits=(16, 2))
    subtotal = fields.Monetary('Subtotal', digits=(16, 2), default=0)
    total = fields.Monetary('Total', digits=(16,2), default=0)

    currency_id = fields.Many2one('res.currency', string='Currency', required=True, related='inter_id.intermedio_id.pricelist_id.currency_id')

    pricelist_id = fields.Many2one('product.pricelist')
    quantity = fields.Integer('Num. de productos', default=1)

    @api.depends('poblacion_id', 'km_active')
    def _compute_see_manual(self):
        for rec in self:
            if rec.km_active:
                rec.see_manual = True if rec.poblacion_id.distancia == 0 else False 
            else:
                rec.see_manual = False

    @api.onchange('inter_id', 'product_id', 'km_extra', 'km_manual', 'time_extra', 'helper_hour', 'linea_manual', 'unit_extra')
    def _update_tax_id(self):
        for line in self:
            fpos = line.inter_id.intermedio_id.fiscal_position_id or line.inter_id.intermedio_id.partner_id.property_account_position_id
            # If company_id is set, always filter taxes by the company
            taxes = line.product_id.taxes_id.filtered(lambda r: not line.inter_id.intermedio_id.company_id or \
                r.company_id == line.inter_id.intermedio_id.company_id)
            line.tax_id = fpos.tax_ids.mapped('tax_src_id') if fpos else taxes

    @api.onchange('product_id')
    def update_active_extras(self):
        for record in self:
            record.km_active = False
            record.time_active = False
            record.helper_hour_active = False
            record.linea_active = False
            record.unit_active = False

            logging.info(f"<<<<<< product: {str(record.product_id.id)}")
            data = self.env['product.invoice'].search([('product_id', '=', record.product_id.id)])
            if data:
                if data.name.code == 'KM':
                    record.km_active = True
                elif data.name.code == 'TE':
                    record.time_active = True
                elif data.name.code == 'HA':
                    record.helper_hour_active = True
                elif data.name.code == 'LM':
                    record.linea_active = True
                elif data.name.code == 'U':
                    record.unit_active = True
    
    def _get_subtotal(self, precio, product_id):
        # Calcular el total de impuestos
        total_tax = 0
        for tax in self.tax_id:
            total_tax += tax.amount 

        subtotal = (precio * total_tax) /100 if total_tax > 0 else 1

        return subtotal

    @api.onchange('product_id', 'km_extra', 'km_manual', 'time_extra', 'helper_hour', 'linea_manual', 'unit_extra', 'quantity')
    def get_prices(self):
        for rec in self:
            unit_price, precio = 0, 0
            p_list = int(str(rec.pricelist_id.id).split('_')[1]) if str(rec.pricelist_id.id).startswith('NewId') else \
            rec.pricelist_id.id
            logging.info(f"<<<<< lista de precios: {str(p_list)}")
            if rec.pricelist_id and rec.product_id:
                price_pricelist = self.env['product.pricelist.item'].search([
                    ('product_tmpl_id', '=', rec.product_id.product_tmpl_id.id),
                    ('pricelist_id', '=',   p_list),
                    ('min_quantity', '<=', rec.quantity),
                ], order='min_quantity desc')
                if not price_pricelist:
                    raise UserError(f"El producto {rec.product_id.name} no se encuentra dentro de la lista de precios seleccionada.")
                unit_price += price_pricelist[0].fixed_price
                precio += price_pricelist[0].fixed_price * rec.get_extra_unit()
            
                logging.info(f"<<<<<<<<<<<< subt: {self._get_subtotal(unit_price, rec.product_id)} -- subt_total: {self._get_subtotal(unit_price, rec.product_id) * rec.get_extra_unit()}")
                
                rec.unit_price = unit_price
                rec.subtotal = precio * rec.quantity
                rec.price_tax = self._get_subtotal(precio, rec.product_id) * rec.quantity
                rec.total = (precio * rec.quantity) + (self._get_subtotal(precio, rec.product_id) * rec.quantity)

    def get_extra_unit(self):
        if self.km_extra > 0:
            return self.km_extra 
        if self.km_manual > 0:
            return self.km_manual
        elif self.time_extra:
            return self.time_extra
        elif self.helper_hour:
            return self.helper_hour
        elif self.linea_manual:
            return self.linea_manual
        elif self.unit_extra:
            return self.unit_extra
        else:
            return 1
    
    @api.onchange('discount')
    def update_prices_by_discount(self):
        for rec in self:
            rec.get_prices()
            if rec.discount > 0 and rec.subtotal and rec.total:
                rec.subtotal -= (rec.subtotal * rec.discount) / 100
                rec.total -= (rec.total * rec.discount) / 100
            