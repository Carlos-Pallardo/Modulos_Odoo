from odoo import models, fields

class ProductInvoice(models.Model):
    _name = 'product.invoice'
    _description = 'Tipo de facturación del producto'

    name = fields.Many2one(comodel_name='type.invoice', string='Tipo de facturación')
    product_id = fields.Many2one('product.product', string="Producto")
