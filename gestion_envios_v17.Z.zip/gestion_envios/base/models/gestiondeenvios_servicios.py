# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Trabajosservicio(models.Model):
    _name = "gestiondeenvios.servicio"

    name = fields.Char(string="Código Servicio")
    tiposervicio = fields.Char(string="Tipo Servicio")
    active = fields.Boolean("Activar", default=True)
