from odoo import models, fields

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    def_product_id = fields.Many2one('product.product', domain="[('detailed_type', '=', 'service')]", string='Servicio de envìo')

    def set_values(self):
        super(ResConfigSettings, self).set_values()
        self.env['ir.config_parameter'].set_param('gestion_envios.def_product_id', self.def_product_id.id)

    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        res['def_product_id'] = self.env['ir.config_parameter'].sudo().get_param('gestion_envios.def_product_id')
        return res