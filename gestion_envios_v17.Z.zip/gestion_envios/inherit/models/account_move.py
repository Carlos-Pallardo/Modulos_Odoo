from odoo import models, api, SUPERUSER_ID
import logging

class AccountMove(models.Model):
    _inherit = 'account.move'

    @api.constrains('move_type', 'invoice_origin', 'state')
    def update_state_in_delivery_order(self):
        self.ensure_one()
        for rec in self:
            if rec.move_type == 'out_invoice' and rec.state == 'posted':
                logging.warning(f'<<<<<<<<<<< move type: {rec.move_type}')
                gest_clase_id = self.env['gestiondeenvios.clase'].with_user(SUPERUSER_ID).search([
                    ('name', '=', rec.invoice_origin),
                ], limit=1)
                logging.warning(f"<<<<<<<<<<<<<< clase: {gest_clase_id.name}")
                if gest_clase_id:
                    gest_clase_id.with_user(SUPERUSER_ID).write({'state': 'done'})