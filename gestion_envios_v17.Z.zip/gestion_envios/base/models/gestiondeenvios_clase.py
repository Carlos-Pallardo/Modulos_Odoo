# -*- coding: utf-8 -*-
import uuid

# from itertools import groupby
from datetime import datetime

import base64
import threading
from odoo import api, fields, models, _, tools, SUPERUSER_ID, exceptions, time
from odoo.exceptions import UserError, AccessError, ValidationError
from odoo.osv import expression
from odoo.tools import float_is_zero, float_compare, DEFAULT_SERVER_DATETIME_FORMAT
from odoo.modules import get_module_resource
from odoo.addons import decimal_precision as dp
import logging

class Gestiondeenviosclase(models.Model):
    _name = "gestiondeenvios.clase"
    _inherit = ['mail.thread', 'mail.activity.mixin', 'portal.mixin']
    _description = "Gestion de envios"
    _order = 'date_order desc, id desc'

    message_follower_ids = fields.One2many(
        'mail.followers', 'res_id', string='Followers')
    activity_ids = fields.One2many('mail.activity', 'res_id', string='Activities')
    message_ids = fields.One2many('mail.message', 'res_id', string='Mensajes')


    sale_id = fields.Many2one("sale.order", 'Venta')
    
    @api.depends('state', 'invoice_id')
    def _get_invoiced(self):
        for order in self:
            if order.state == 'sale' and not order.invoice_id:
                order.invoice_status = 'to invoice'
            elif order.invoice_id and order.state == 'done':
                order.invoice_status = 'invoiced'
            else:
                order.invoice_status = 'no'    
            
    
    @api.model
    def get_empty_list_help(self, help):
        if help and help.find("oe_view_nocontent_create") == -1:
            return '<p class="oe_view_nocontent_create">%s</p>' % (help)
        return super(Gestiondeenviosclase, self).get_empty_list_help(help)

    def _get_default_access_token(self):
        return str(uuid.uuid4())

    @api.model
    def _default_note(self):
        return self.env['ir.config_parameter'].sudo().get_param(
            'sale.use_sale_note') and self.env.user.company_id.sale_note or ''

    @api.model
    def _get_default_team(self):
        return self.env['crm.team']._get_default_team_id()

    @api.onchange('fiscal_position_id')
    def _compute_tax_id(self):
        for order in self:
            for intermedio in order.gestiondeenvios_line:
                intermedio.line_id._compute_tax_id()

    def _get_payment_type(self):
        self.ensure_one()
        return 'form'

    name = fields.Char(string='Referencia de Envío', copy=False, readonly=True, index=True, required=True,
                       default=lambda self: _('New'))
    albaran = fields.Char(string='Nº Albarán', copy=False, readonly=False, index=True, required=False)
    tipoalbaran = fields.Boolean(string="Es albarán?", default=False)
    datealbaran = fields.Datetime(string='Fecha de Albarán', select=True, default=fields.Datetime.now)
    parent_id = fields.Many2one("res.partner", string='Empleado Solicitante',
                                states={'draft': [('readonly', False)], 'sent': [('readonly', False)]},
                                change_default=True, required=True, index=True, track_visibility='always')
    partner_id = fields.Many2one("res.partner", string='Empresa de Facturación',
                                 store=True, related="parent_id.commercial_partner_id")

    move_ref = fields.Char("Referencia")

    @api.onchange('parent_id')
    def get_partner(self):
        for record in self:
            if record.parent_id:
                record.partner_id = record.parent_id.commercial_partner_id.id or record.parent_id.parent_id.id

    street = fields.Char(related="partner_id.street", readonly=True)
    street2 = fields.Char(related="partner_id.street2", readonly=True)
    city = fields.Char(related="partner_id.city", readonly=True)
    state_id = fields.Many2one("res.country.state", related="partner_id.state_id", string='State', ondelete='restrict',
                               readonly=True)
    zip = fields.Char(related="partner_id.zip", readonly=True)
    country_id = fields.Many2one('res.country', related="partner_id.country_id", string='Country', ondelete='restrict',
                                 readonly=True)

    user_id = fields.Many2one('res.users', string='Comercial', index=True, track_visibility='onchange',
                              default=lambda self: self.env.user)

    horasolicitud = fields.Datetime(string='Fecha de Solicitud', required=True, readonly=True, select=True,
                                    default=fields.Datetime.now)

    gestiondeenvios_line = fields.One2many('gestiondeenvios.intermedio', 'intermedio_id', string='Order Lines',
                                          copy=True)

    estado = fields.Selection([
        ('PE', 'Pendiente'),
        ('FI', 'Finalizado'),
        ('IN', 'Finalizado con Incidencia'),
        ('FA', 'Facturado'),
        ('CA', 'Cancelado')
    ], compute="_get_estado", string="Estado", required=True, default='PE', store=True)

    # actualiza el estado del pedido en funcion de las tareas
    @api.depends('gestiondeenvios_line.stage_id', 'invoice_status', 'state')
    def _get_estado(self):
        for order in self:
            contadorlineas = 0
            contadorfinalizados = 0
            for intermedio in order.gestiondeenvios_line:
                contadorlineas += 1
                if intermedio.stage_id.id == 2:
                    contadorfinalizados += 1

            contadorlineas2 = 0
            contadorfinalizados2 = 0
            for intermedio in order.gestiondeenvios_line:
                contadorlineas2 += 1
                if intermedio.stage_id.id == 2:
                    contadorfinalizados2 += 1
                if intermedio.stage_id.id == 3:
                    contadorfinalizados2 += 1

            if contadorfinalizados == contadorlineas and contadorfinalizados > 0 and contadorlineas > 0:
                order.estado = 'FI'
            elif contadorfinalizados2 == contadorlineas2 and contadorfinalizados2 > 0 and contadorlineas2 > 0:
                order.estado = 'IN'
            else:
                order.estado = 'PE'
            
    # actualiza el nombre de la empresa en funcion del empleado seleccionado
    @api.onchange('parent_id')
    def actualizarempresa(self):
        if self.parent_id:
            idempresa = self.env['res.partner'].search([('id', '=', self.parent_id.id)], limit=1).commercial_partner_id
            escliente = self.env['res.partner'].search([('id', '=', idempresa.id)]).is_customer
            if escliente:
                self.partner_id = idempresa
            else:
                self.partner_id = False

    origin = fields.Char(string='Source Document',
                         help="Reference of the document that generated this sales order request.")
    client_order_ref = fields.Char(string='Customer Reference', copy=False)
    access_token = fields.Char(
        'Security Token', copy=False,
        default=_get_default_access_token)
    state = fields.Selection([
        ('draft', 'Quotation'),
        ('sent', 'Quotation Sent'),
        ('sale', 'Sales Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled'),
    ], string='Status', readonly=True, copy=False, index=True, track_visibility='onchange', default='draft')
    date_order = fields.Datetime(string='Order Date', required=True, readonly=True, index=True,
                                 states={'draft': [('readonly', False)], 'sent': [('readonly', False)]}, copy=False,
                                 default=fields.Datetime.now)
    validity_date = fields.Date(string='Expiration Date', readonly=True, copy=False,
                                states={'draft': [('readonly', False)], 'sent': [('readonly', False)]},
                                help="Manually set the expiration date of your quotation (offer), or it will set the date automatically based on the template if online quotation is installed.")
    is_expired = fields.Boolean(compute='_compute_is_expired', string="Is expired")
    create_date = fields.Datetime(string='Creation Date', readonly=True, index=True,
                                  help="Date on which sales order is created.")
    confirmation_date = fields.Datetime(string='Confirmation Date', readonly=True, index=True,
                                        help="Date on which the sales order is confirmed.", oldname="date_confirm",
                                        copy=False)

    partner_invoice_id = fields.Many2one('res.partner', string='Dirección de facturación', readonly=False, required=True,
                                         states={'draft': [('readonly', False)], 'sent': [('readonly', False)]},
                                         help="Invoice address for current sales order.", compute="_compute_partner_invoice",
                                         store=True)
    
    pricelist_id = fields.Many2one('product.pricelist', string='Tarifa', required=True, store=True,
                                   help="Pricelist for current sales order.")

    currency_id = fields.Many2one("res.currency", related='pricelist_id.currency_id', string="Currency", readonly=True,
                                  required=True)
    analytic_account_id = fields.Many2one('account.analytic.account', 'Analytic Account', readonly=True,
                                          states={'draft': [('readonly', False)], 'sent': [('readonly', False)]},
                                          help="The analytic account related to a sales order.", copy=False,
                                          oldname='project_id')

    #order_line = fields.One2many('gestiondeenvios.line', 'order_id', string='Order Lines',
    #                             states={'cancel': [('readonly', True)], 'done': [('readonly', True)]}, copy=True,
    #                             auto_join=True)

    invoice_count = fields.Integer(string='# of Invoices', compute='_get_invoiced', readonly=True)
    invoice_ids = fields.Many2many("account.invoice", string='Invoices', compute="_get_invoiced", readonly=True,
                                   copy=False)
    invoice_id = fields.Many2one('account.move', string="Factura")
    invoice_status = fields.Selection([
        ('upselling', 'Upselling Opportunity'),
        ('invoiced', 'Fully Invoiced'),
        ('to invoice', 'To Invoice'),
        ('no', 'Nothing to Invoice')
    ], string='Invoice Status', compute='_get_invoiced', store=True, readonly=True, default='no')

    note = fields.Text('Notas de pedido', default=_default_note)

    amount_untaxed = fields.Monetary(string='Untaxed Amount', store=True, readonly=True, compute='_amount_all',
                                     track_visibility='onchange')

    amount_tax = fields.Monetary(string='Taxes', store=True, readonly=True, compute='_amount_all')
    amount_total = fields.Monetary(string='Total', store=True, readonly=True, compute='_amount_all',
                                   track_visibility='always')
    
    @api.depends('gestiondeenvios_line')
    def _amount_all(self):
        for rec in self:
            rec.amount_untaxed = sum(line.price_subtotal for line in rec.gestiondeenvios_line)
            rec.amount_total = sum(line.price_total for line in rec.gestiondeenvios_line)
            rec.amount_tax = rec.amount_total - rec.amount_untaxed

    payment_term_id = fields.Many2one('account.payment.term', string='Payment Terms', related="partner_id.property_payment_term_id", store=True)
    fiscal_position_id = fields.Many2one('account.fiscal.position', string='Fiscal Position')
    company_id = fields.Many2one('res.company', 'Company',
                                 default=lambda self: self.env['res.company']._company_default_get(
                                     'gestiondeenvios.clase'))
    team_id = fields.Many2one('crm.team', 'Sales Channel', change_default=True, default=_get_default_team,
                              oldname='section_id')

    cargo_expediente = fields.Char('Cargo Expediente', store=True,
                                   help="Referencia de refacturación, para que el cliente pueda refacturar a sus clientes. Si se rellena este campo aparecerá en las lineas de factura de este albarán.")
    contacts_partner_ids = fields.Many2many('res.partner', string='Contactos del partner', compute='_compute_contacts')
    invoice_partner_ids = fields.Many2many('res.partner', string='Facturas del partner', compute='_compute_contacts')

    @api.constrains('cargo_expediente')
    def update_ref_lines(self):
        for record in self:
            if record.cargo_expediente:
                for item in record.gestiondeenvios_line:
                    item.move_ref = record.cargo_expediente

    @api.depends('partner_id')
    def _compute_contacts(self):
        contact_ids = invoice_ids = []
        for rec in self:
            if rec.partner_id:
                contact_ids = rec.partner_id.child_ids.filtered(lambda x: x.type == 'contact' and x.is_company == False).ids
                invoice_ids = rec.partner_id.child_ids.filtered(lambda x: x.type == 'invoice' and x.is_company == False).ids
            rec.contacts_partner_ids = [(6, 0, contact_ids)]
            rec.invoice_partner_ids = [(6, 0, invoice_ids)]

    @api.depends('parent_id')
    def _compute_partner_invoice(self):
        for record in self:
            if not record.parent_id.parent_id:
                raise UserError(f"El contacto {record.partner_id.name} no està asociado a ninguna empresa.")
            invoice_records = record.parent_id.parent_id.child_ids.filtered(lambda x: x.type == 'invoice')
            for invoice in invoice_records:
                logging.info(f"Dirección de facturación: {invoice.name}")  # O cualquier otro campo que necesites
                # Puedes asignar valores a otros campos del registro actual
                record.partner_invoice_id = invoice.id
            if not record.partner_invoice_id:
                record.partner_invoice_id = False

    def _compute_portal_url(self):
        super(Gestiondeenviosclase, self)._compute_portal_url()
        for order in self:
            order.portal_url = '/my/orders/%s' % (order.id)

    def _compute_is_expired(self):
        now = datetime.now()
        for order in self:
            if order.validity_date and fields.Datetime.from_string(order.validity_date) < now:
                order.is_expired = True
            else:
                order.is_expired = False

    @api.model
    def _get_customer_lead(self, product_tmpl_id):
        return False

    def unlink(self):
        for order in self:
            if order.state not in ('draft', 'cancel'):
                raise UserError(_('You can not delete a sent quotation or a sales order! Try to cancel it before.'))
        return super(Gestiondeenviosclase, self).unlink()

    @api.onchange('partner_id')
    def onchange_partner_shipping_id(self):
        self.fiscal_position_id = self.env['account.fiscal.position']._get_fiscal_position(self.partner_id)
        return {}

    @api.onchange('partner_id')
    def onchange_partner_id(self):
        if not self.partner_id:
            self.update({
                'partner_invoice_id': False,
                'fiscal_position_id': False,
            })
            return
        
        addr = self.partner_id.address_get(['delivery', 'invoice'])
        values = {
            'pricelist_id': self.partner_id.property_product_pricelist and self.partner_id.property_product_pricelist.id or False,
            'partner_invoice_id': addr['invoice'],
            'user_id': self.partner_id.user_id.id or self.env.uid
        }
        if self.env['ir.config_parameter'].sudo().get_param(
                'sale.use_sale_note') and self.env.user.company_id.sale_note:
            values['note'] = self.with_context(lang=self.partner_id.lang).env.user.company_id.sale_note

        if self.partner_id.team_id:
            values['team_id'] = self.partner_id.team_id.id
        self.update(values)

    @api.onchange('partner_id')
    def onchange_partner_id_warning(self):
        if not self.partner_id:
            return
        warning = {}
        title = False
        message = False
        partner = self.partner_id

        # If partner has no warning, check its company
        if partner.sale_warn == 'no-message' and partner.parent_id:
            partner = partner.parent_id

        if partner.sale_warn != 'no-message':
            # Block if partner only has warning but parent company is blocked
            if partner.sale_warn != 'block' and partner.parent_id and partner.parent_id.sale_warn == 'block':
                partner = partner.parent_id
            title = ("Warning for %s") % partner.name
            message = partner.sale_warn_msg
            warning = {
                'title': title,
                'message': message,
            }
            if partner.sale_warn == 'block':
                self.update({'partner_id': False, 'partner_invoice_id': False,
                             'pricelist_id': False})
                return {'warning': warning}

        if warning:
            return {'warning': warning}

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            if 'company_id' in vals:
                if vals.get('tipoalbaran'):
                    vals['name'] = self.env['ir.sequence'].with_context(force_company=vals['company_id']).next_by_code(
                        'increment_albaran') or _('New')
                else:
                    vals['name'] = self.env['ir.sequence'].with_context(force_company=vals['company_id']).next_by_code(
                        'increment_your_field') or _('New')
            else:
                if vals.get('tipoalbaran'):
                    vals['name'] = self.env['ir.sequence'].next_by_code('increment_albaran') or _('New')
                else:
                    vals['name'] = self.env['ir.sequence'].next_by_code('increment_your_field') or _('New')

        # Makes sure partner_invoice_id' and 'pricelist_id' are defined
        if any(f not in vals for f in ['partner_invoice_id', 'pricelist_id']):
            partner = self.env['res.partner'].browse(vals.get('partner_id'))
            addr = partner.address_get(['delivery', 'invoice'])
            vals['partner_invoice_id'] = vals.setdefault('partner_invoice_id', addr['invoice'])
            vals['pricelist_id'] = vals.setdefault('pricelist_id',
                                                   partner.property_product_pricelist and partner.property_product_pricelist.id)
        result = super().create(vals)
        return result

    '''

    def copy_data(self, default=None):
        if default is None:
            default = {}
        if 'order_line' not in default:
            default['order_line'] = [(0, 0, line.copy_data()[0]) for line in
                                     self.order_line.filtered(lambda l: not l.is_downpayment)]
        return super(Gestiondeenviosclase, self).copy_data(default)
    '''

    def name_get(self):
        if self._context.get('sale_show_partner_name'):
            res = []
            for order in self:
                name = order.name
                if order.partner_id.name:
                    name = '%s - %s' % (name, order.partner_id.name)
                res.append((order.id, name))
            return res
        return super(Gestiondeenviosclase, self).name_get()

    @api.model
    def name_search(self, name='', args=None, operator='ilike', limit=100):
        if self._context.get('sale_show_partner_name'):
            if operator in ('ilike', 'like', '=', '=like', '=ilike'):
                domain = expression.AND([
                    args or [],
                    ['|', ('name', operator, name), ('partner_id.name', operator, name)]
                ])
                return self.search(domain, limit=limit).name_get()
        return super(Gestiondeenviosclase, self).name_search(name, args, operator, limit)

    def _init_column(self, column_name):
        if column_name != 'access_token':
            super(Gestiondeenviosclase, self)._init_column(column_name)
        else:
            query = """UPDATE %(table_name)s
                              SET %(column_name)s = md5(md5(random()::varchar || id::varchar) || clock_timestamp()::varchar)::uuid::varchar
                            WHERE %(column_name)s IS NULL
                        """ % {'table_name': self._table, 'column_name': column_name}
            self.env.cr.execute(query)

    def _generate_access_token(self):
        for order in self:
            order.access_token = self._get_default_access_token()

    def prepare_invoice(self, date_inv=False):
        if not all(rec.estado == 'FI' for rec in self.gestiondeenvios_line):
            raise UserError("Tiene actividades sin finalizar.")

        self.ensure_one()
        product_settings = self.env['ir.config_parameter'].sudo().get_param('gestion_envios.def_product_id')
        product_id = self.env['product.product'].browse(int(product_settings))
        total_tax = 1 + (sum(tax.amount for tax in product_id.taxes_id) / 100) 
        invoice_vals = {
            'invoice_origin': self.name,
            'move_type': 'out_invoice',
            'partner_id': self.partner_invoice_id.id,
            'ref': self.partner_invoice_id.ref,
            'currency_id': self.pricelist_id.currency_id.id,
            'invoice_payment_term_id': self.payment_term_id.id,
            'fiscal_position_id': self.fiscal_position_id.id or self.partner_invoice_id.property_account_position_id.id,
            'company_id': self.company_id.id,
            'user_id': self.user_id and self.user_id.id,
            #'team_id': self.team_id.id
        }
        if self.tipoalbaran:
            invoice_vals.update({'origin': self.albaran})

        invoice = self.env['account.move'].with_user(SUPERUSER_ID).create(invoice_vals)
        inv_line = self.env['account.move.line'].with_user(SUPERUSER_ID).create({
            'name': 'Servicio de envio',
            'ref': self.name,
            #'account_id': self.partner_id.property_account_receivable_id.id,
            'price_unit': self.amount_total / total_tax,
            #'price_subtotal': self.amount_untaxed,
            #'price_total': self.amount_total,
            'quantity': 1.0,
            'discount': 0.0,
            'product_id': product_id.id,
            'move_id': invoice.id, 
        })
        self.invoice_id = invoice.id
       

    def action_open_invoice(self):
        action = self.env.ref('account.action_move_out_invoice_type').read()[0]
        action['views'] = [(self.env.ref('account.view_move_form').id, 'form')]
        action['res_id'] = self.invoice_id.id
        return action

    def print_quotation(self):
        self.filtered(lambda s: s.state == 'draft').write({'state': 'sent'})
        return self.env.ref('sale.action_report_saleorder').report_action(self)

    def action_view_invoice(self):
        invoices = self.mapped('invoice_ids')
        action = self.env.ref('account.action_invoice_tree1').read()[0]
        if len(invoices) > 1:
            action['domain'] = [('id', 'in', invoices.ids)]
        elif len(invoices) == 1:
            action['views'] = [(self.env.ref('account.invoice_form').id, 'form')]
            action['res_id'] = invoices.ids[0]
        else:
            action = {'type': 'ir.actions.act_window_close'}
        return action

    def action_invoice_create(self, grouped=False, final=False, date=False):
        inv_obj = self.env['account.invoice']
        precision = self.env['decimal.precision'].precision_get('Product Unit of Measure')
        invoices = {}
        references = {}
        invoices_origin = {}
        invoices_name = {}

        for order in self:
            if order.estado == 'PE':
                raise UserError("No puedes facturar un envío que no ha sido finalizado")
            group_key = order.id if grouped else (order.partner_invoice_id.id, order.currency_id.id)
            for intermedio in order.gestiondeenvios_line:
                for line in intermedio.line_id.sorted(key=lambda l: l.qty_to_invoice < 0):
                    if float_is_zero(line.qty_to_invoice, precision_digits=precision):
                        continue
                    if group_key not in invoices:
                        inv_data = order._prepare_invoice(date_inv=date)
                        invoice = inv_obj.create(inv_data)
                        references[invoice] = order
                        invoices[group_key] = invoice
                        invoices_origin[group_key] = [invoice.origin]
                        if invoice.tipoalbaran:
                            invoices_origin[group_key] = [order.albaran]
                        invoices_name[group_key] = [invoice.name]
                    elif group_key in invoices:
                        if order.tipoalbaran:
                            if order.albaran not in invoices_origin[group_key] and invoice:
                                invoices_origin[group_key].append(order.albaran)
                            if order.client_order_ref and order.client_order_ref not in invoices_name[group_key]:
                                invoices_name[group_key].append(order.client_order_ref)
                        else:
                            if order.name not in invoices_origin[group_key] and invoice:
                                invoices_origin[group_key].append(order.name)
                            if order.client_order_ref and order.client_order_ref not in invoices_name[group_key]:
                                invoices_name[group_key].append(order.client_order_ref)

                    if line.qty_to_invoice > 0:
                        line.invoice_line_create(invoices[group_key].id, line.qty_to_invoice)
                    elif line.qty_to_invoice < 0 and final:
                        line.invoice_line_create(invoices[group_key].id, line.qty_to_invoice)

            if references.get(invoices.get(group_key)):
                if order not in references[invoices[group_key]]:
                    references[invoices[group_key]] |= order

        for group_key in invoices:
            invoices[group_key].write({'name': ', '.join(invoices_name[group_key]),
                                       'origin': ', '.join(invoices_origin[group_key])})

        if not invoices:
            raise UserError(_('There is no invoiceable line.'))

        for invoice in invoices.values():
            invoice.compute_taxes()
            if not invoice.invoice_line_ids:
                raise UserError(_('There is no invoiceable line.'))
            # If invoice is negative, do a refund invoice instead
            if invoice.amount_total < 0:
                invoice.type = 'out_refund'
                for line in invoice.invoice_line_ids:
                    line.quantity = -line.quantity
            # Use additional field helper function (for account extensions)
            for line in invoice.invoice_line_ids:
                line._set_additional_fields(invoice)
            # Necessary to force computation of taxes. In account_invoice, they are triggered
            # by onchanges, which are not triggered when doing a create.
            invoice.compute_taxes()
            invoice.message_post_with_view('mail.message_origin_link',
                                           values={'self': invoice, 'origin': references[invoice]},
                                           subtype_id=self.env.ref('mail.mt_note').id)
        return [inv.id for inv in invoices.values()]

    def action_draft(self):
        orders = self.filtered(lambda s: s.state in ['cancel', 'sent'])
        return orders.write({
            'state': 'draft',
        })

    def action_cancel(self):
        #for intermedio in self.gestiondeenvios_line:
        #    intermedio.write({
        #        'state': 'cancel',
        #    })
        self.state = 'cancel'

    def action_quotation_send(self):
        '''
        This function opens a window to compose an email, with the edi sale template message loaded by default
        '''
        self.ensure_one()
        ir_model_data = self.env['ir.model.data']
        try:
            template_id = ir_model_data.get_object_reference('sale', 'email_template_edi_sale')[1]
        except ValueError:
            template_id = False
        try:
            compose_form_id = ir_model_data.get_object_reference('mail', 'email_compose_message_wizard_form')[1]
        except ValueError:
            compose_form_id = False
        ctx = {
            'default_model': 'gestiondeenvios.clase',
            'default_res_id': self.ids[0],
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'mark_so_as_sent': True,
            'custom_layout': "sale.mail_template_data_notification_email_sale_order",
            'proforma': self.env.context.get('proforma', False),
            'force_email': True
        }
        return {
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(compose_form_id, 'form')],
            'view_id': compose_form_id,
            'target': 'new',
            'context': ctx,
        }

    def force_quotation_send(self):
        for order in self:
            email_act = order.action_quotation_send()
            if email_act and email_act.get('context'):
                email_ctx = email_act['context']
                email_ctx.update(default_email_from=order.company_id.email)
                order.with_context(email_ctx).message_post_with_template(email_ctx.get('default_template_id'))
        return True

    def action_done(self):
        return self.write({'state': 'done'})

    def action_unlock(self):
        self.write({'state': 'sale'})

    def _action_confirm(self):
        if self.partner_id.id not in self.message_follower_ids.mapped('partner_id.id'):
            self.message_subscribe([self.partner_id.id])
            self.message_follower_ids = [(4, 0, self.partner_id.id)]
        self.write({
            'state': 'sale',
            'confirmation_date': fields.Datetime.now()
        })
        if self.env.context.get('send_email'):
            self.force_quotation_send()

        # create an analytic account if at least an expense product
        if any([expense_policy != 'no' for expense_policy in
                self.gestiondeenvios_line.mapped('product_id.expense_policy')]):
            if not self.analytic_account_id:
                self._create_analytic_account()
        return True

    def action_confirm(self):
        if self._get_forbidden_state_confirm() & set(self.mapped('state')):
            raise UserError(_(
                'It is not allowed to confirm an order in the following states: %s'
            ) % (', '.join(self._get_forbidden_state_confirm())))
        self._action_confirm()
        if self.env['ir.config_parameter'].sudo().get_param('sale.auto_done_setting'):
            self.action_done()
        return True

    def _action_confirm_albaran(self):
        for order in self.filtered(lambda order: order.partner_id not in order.message_partner_ids):
            order.message_subscribe([order.partner_id.id])
        self.write({
            'state': 'sale',
            'confirmation_date': fields.Datetime.now()
        })
        for intermedio in self.gestiondeenvios_line:
            intermedio.write({
                'stage_id': 1,
            })
        if self.env.context.get('send_email'):
            self.force_quotation_send()

        # create an analytic account if at least an expense product
        if any([expense_policy != 'no' for expense_policy in
                self.gestiondeenvios_line.mapped('product_id.expense_policy')]):
            if not self.analytic_account_id:
                self._create_analytic_account()
        return True

    def action_confirm_albaran(self):
        if self._get_forbidden_state_confirm() & set(self.mapped('state')):
            raise UserError(_(
                'It is not allowed to confirm an order in the following states: %s'
            ) % (', '.join(self._get_forbidden_state_confirm())))
        self._action_confirm_albaran()
        if self.env['ir.config_parameter'].sudo().get_param('sale.auto_done_setting'):
            self.action_done()
        return True

    def _action_cancelar_albaran(self):
        for order in self.filtered(lambda order: order.partner_id not in order.message_partner_ids):
            order.message_subscribe([order.partner_id.id])
        self.write({
            'state': 'cancel',
            'estado': 'CA'
        })
        return True

    def action_cancelar_albaran(self):
        if self._get_forbidden_state_confirm() & set(self.mapped('state')):
            raise UserError(_(
                'It is not allowed to confirm an order in the following states: %s'
            ) % (', '.join(self._get_forbidden_state_confirm())))
        self._action_cancelar_albaran()
        if self.env['ir.config_parameter'].sudo().get_param('sale.auto_done_setting'):
            self.action_done()
        return True

    def _get_forbidden_state_confirm(self):
        return {'done', 'cancel'}

    def _create_analytic_account(self, prefix=None):
        for order in self:
            name = order.name
            if prefix:
                name = prefix + ": " + order.name
            analytic = self.env['account.analytic.account'].create({
                'name': name,
                'code': order.client_order_ref,
                'company_id': order.company_id.id,
                'partner_id': order.partner_id.id
            })
            order.analytic_account_id = analytic

    def get_access_action(self, access_uid=None):
        # TDE note: read access on sales order to portal users granted to followed sales orders
        self.ensure_one()

        if self.state != 'cancel' and (self.state != 'draft' or self.env.context.get('mark_so_as_sent')):
            user, record = self.env.user, self
            if access_uid:
                user = self.env['res.users'].sudo().browse(access_uid)
                record = self.sudo(user)
            if user.share or self.env.context.get('force_website'):
                try:
                    record.check_access_rule('read')
                except AccessError:
                    if self.env.context.get('force_website'):
                        return {
                            'type': 'ir.actions.act_url',
                            'url': '/my/orders/%s' % self.id,
                            'target': 'self',
                            'res_id': self.id,
                        }
                    else:
                        pass
                else:
                    return {
                        'type': 'ir.actions.act_url',
                        'url': '/my/orders/%s?access_token=%s' % (self.id, self.access_token),
                        'target': 'self',
                        'res_id': self.id,
                    }
        else:
            action = self.env.ref('sale.action_quotations', False)
            if action:
                result = action.read()[0]
                result['res_id'] = self.id
                return result
        return super(Gestiondeenviosclase, self).get_access_action(access_uid)

    def get_mail_url(self):
        return self.get_share_url()

    def get_portal_confirmation_action(self):
        return self.env['ir.config_parameter'].sudo().get_param('sale.sale_portal_confirmation_options', default='none')

    def _notification_recipients(self, message, groups):
        groups = super(Gestiondeenviosclase, self)._notification_recipients(message, groups)

        self.ensure_one()
        if self.state not in ('draft', 'cancel'):
            for group_name, group_method, group_data in groups:
                if group_name == 'customer':
                    continue
                group_data['has_button_access'] = True

        return groups

    def cancel_confirmed(self):
        for record in self:
            sale = self.env['sale.order'].sudo().search([('origin', '=', self.name), ('state', '=', 'finished')], limit=1)
            if sale:
                sale.action_cancel()
            record.state = 'draft'
            for item in record.gestiondeenvios_line:
                item.estado = 'PA'
                item.invoice_status = 'to invoice'
                item.stage_id = self.env['gestiondeenvios.stage'].sudo().search([('sequence', '=', 0)], limit=1).id
