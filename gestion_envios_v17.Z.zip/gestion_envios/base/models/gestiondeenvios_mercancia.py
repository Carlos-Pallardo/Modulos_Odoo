# -*- coding: utf-8 -*-

from odoo import models, fields, api

class Trabajosmercancia(models.Model):
    _name = "gestiondeenvios.mercancia"

    @api.depends('codigo', 'tipomercancia')
    def _computar_nombre(self):
        for record in self:
            record.name = "[" + str(record.codigo) + "] " + str(record.tipomercancia)

    name = fields.Char(string="Mercancía", compute='_computar_nombre', store=True)
    codigo = fields.Char(string="Código Mercancia", required=True)
    tipomercancia = fields.Char(string="Tipo Mercancia", required=True)
    preguntarpeso = fields.Boolean(string="¿Preguntar peso?")
    preguntarmedidas = fields.Boolean(string="¿Preguntar medidas?")
    plantillanotas = fields.Text(string="Nota de tarea")
    active = fields.Boolean("Activar", default=True)
