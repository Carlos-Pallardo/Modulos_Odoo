# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _, SUPERUSER_ID

AVAILABLE_PRIORITIES = [
    ('0', 'Normal'),
    ('1', 'Low'),
    ('2', 'High'),
    ('3', 'Very High'),
]


class GestiondeenviosStage(models.Model):
    """ Model for case stages. This models the main stages of a document
        management flow. Main CRM objects (leads, opportunities, project
        issues, ...) will now use only stages, instead of state and stages.
        Stages are for example used to display the kanban view of records.
    """
    _name = "gestiondeenvios.stage"
    _description = "Stage of case"
    _rec_name = 'name'
    _order = "sequence, name, id"

    name = fields.Char('Nombre Etapa', required=True, translate=True)
    sequence = fields.Integer('Secuencia', default=1, help="Used to order stages. Lower is better.")
    team_id = fields.Many2one('crm.team', string='Equipo', ondelete='set null',
        help='Especifica qué grupo utiliza esta etapa. Otros equipos no serán capaces de ver o usar esta etapa.')
    fold = fields.Boolean('Plegar Columna', default=True,
        help='Esta etapa se plegará en la vista kanban cuando no haya registros que mostrar en esta etapa.')
    mensajerorelacionado = fields.Many2one('hr.employee', string="Mensajero Relacionado")

    asignarenvios = fields.Boolean(string="¿Asignar envíos?", default=False, store=True,
                                   help="Si se marca abrirá una columna en el apartado Asignación Mensajeros del módulo Gestión de Envíos")

    def update_name(self, name):
        self.with_user(SUPERUSER_ID).write({'name': name})