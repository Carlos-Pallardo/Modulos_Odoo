/** @odoo-module */

import { KanbanController } from "@web/views/kanban/kanban_controller";
import { kanbanView } from "@web/views/kanban/kanban_view";
import { registry } from "@web/core/registry";

class CustomKanbanController extends KanbanController {
    constructor() {
        super(...arguments);
        this.busService = this.env.services.bus_service;
        this.channel = "kanban_update";
        console.log("<<<<<<<< envios desde js file...")
        // Agregar el canal y escuchar el evento de notificación
        this.busService.addChannel(this.channel);
        this.busService.addEventListener('notification', this.onMessage.bind(this));
    }

    onMessage({ detail: notifications }) {
        // Filtrar las notificaciones que provienen de tu canal específico
        notifications = notifications.filter(item => item.payload.channel === this.channel);
        
        notifications.forEach(item => {
            console.log(item.payload.data);
            this.model.load();
        });
    }
}

//CustomKanbanController.template = "gestion_envios.kanban-box";

export const customKanbanView = {
    ...kanbanView,
    Controller: CustomKanbanController,
};

// Registra la vista personalizada dentro del sistema de vistas de Odoo
registry.category("views").add("kanban_view_env", customKanbanView);
