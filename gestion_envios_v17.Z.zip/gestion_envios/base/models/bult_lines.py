from odoo import models, fields, api 

class BultLines(models.Model):
    _name = 'bult.lines'
    _description = 'Bultos y caracterìsticas'

    peso = fields.Float('Peso', digits=(12,2))
    alto = fields.Float('Alto', digits=(12,2)) 
    ancho = fields.Float('Ancho', digits=(12,2)) 
    fondo = fields.Float('Fondo', digits=(12,2))
    inter_id = fields.Many2one('gestiondeenvios.intermedio', string='Gestiòn clase')
    quantity = fields.Integer('Nº bultos', default=1)