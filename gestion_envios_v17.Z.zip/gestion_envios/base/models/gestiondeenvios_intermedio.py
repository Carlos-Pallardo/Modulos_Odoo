# -*- coding: utf-8 -*-
import uuid

# from itertools import groupby
from datetime import datetime, timedelta

import base64
import threading, logging
from odoo import api, fields, models, _, tools, SUPERUSER_ID, exceptions, time
from odoo.exceptions import UserError, AccessError, ValidationError
from odoo.osv import expression
from odoo.tools import float_is_zero, float_compare, DEFAULT_SERVER_DATETIME_FORMAT
from odoo.modules import get_module_resource
from odoo.addons import decimal_precision as dp

class Gestiondeenviosintermedio(models.Model):
    _name = 'gestiondeenvios.intermedio'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'portal.mixin']
    _description = 'Tabla visible del modulo'
    _order = 'sequence'

    message_follower_ids = fields.One2many(
        'mail.followers', 'res_id', string='Followers')
    activity_ids = fields.One2many('mail.activity', 'res_id', string='Activities')
    message_ids = fields.One2many('mail.message', 'res_id', string='Mensajes')
    color = fields.Char(string='Color', default="#28A745")
    moved = fields.Boolean("Actualizado recientemente")
    prods = fields.Html('Prods', compute="_compute_prods")

    @api.depends('ref_ids')
    def _compute_prods(self):
        for record in self:
            items = [rec.default_code for rec in record.ref_ids.mapped('product_id')]
            if not items:
                record.prods = 'No products'
            else:
                items_html = ''.join([f"<li>{item}</li>" for item in items])
                record.prods = f"""
                    <ul>
                        {items_html}
                    </ul>
                """

    def _default_stage_id(self):
        team = self.env['crm.team'].sudo()._get_default_team_id(user_id=self.env.uid)
        return self._stage_find(team_id=team.id, domain=[('fold', '=', False)]).id

    def _stage_find(self, team_id=False, domain=None, order='sequence'):
        # collect all team_ids by adding given one, and the ones related to the current leads
        team_ids = set()
        if team_id:
            team_ids.add(team_id)
        for lead in self:
            if lead.team_id:
                team_ids.add(lead.team_id.id)
        # generate the domain
        if team_ids:
            search_domain = ['|', ('team_id', '=', False), ('team_id', 'in', list(team_ids))]
        else:
            search_domain = [('team_id', '=', False)]
        # AND with the domain in parameter
        if domain:
            search_domain += list(domain)
        # perform search, return the first found
        return self.env['gestiondeenvios.stage'].search(search_domain, order=order, limit=1)

    @api.depends('tiposervicio', 'tipomercancia', 'contacto', 'nbultos', 'referencias')
    def _get_nombre(self):
        for intermedio in self:
            intermedio.name = ''
            for referencia in intermedio.referencias:
                intermedio.name += "[" + referencia.default_code + "]"
            intermedio.name += str(intermedio.tiposervicio.name) + "/" + str(intermedio.nbultos) + " " + str(
                intermedio.tipomercancia.tipomercancia) + ", " + str(intermedio.contacto.display_name)

    intermedio_id = fields.Many2one('gestiondeenvios.clase', string='Order Reference', required=True,
                                    ondelete='cascade',
                                    index=True, copy=False)

    parent_id = fields.Many2one("res.partner", string="Empleado Solicitante", compute="_get_parent_id", store=True)
    partner_id = fields.Many2one("res.partner", string="Empresa Solicitante", compute="_get_partner_id", store=True)

    tipoalbaran = fields.Boolean(string="Es albarán?", compute="_compute_tipoalbaran", store=True)
    bult_lines = fields.One2many('bult.lines', 'inter_id')

    @api.depends('intermedio_id.tipoalbaran')
    def _compute_tipoalbaran(self):
        for intermedio in self:
            intermedio.tipoalbaran = intermedio.intermedio_id.tipoalbaran

    @api.depends('intermedio_id.parent_id')
    def _get_parent_id(self):
        for intermedio in self:
            intermedio.parent_id = intermedio.intermedio_id.parent_id

    @api.depends('intermedio_id.partner_id')
    def _get_partner_id(self):
        for intermedio in self:
            intermedio.partner_id = intermedio.intermedio_id.partner_id

    user_id = fields.Many2one('res.users', string='Comercial', store=True, compute="_get_user_id")

    @api.depends('intermedio_id.user_id')
    def _get_user_id(self):
        for intermedio in self:
            intermedio.user_id = intermedio.intermedio_id.user_id

    @api.depends('intermedio_id.name')
    def _get_referencia(self):
        for intermedio in self:
            intermedio.referencia = intermedio.intermedio_id.name

    name = fields.Char(string="Tarea", compute="_get_nombre", store=True)
    referencia = fields.Char(string="Referencia de Envío", compute="_get_referencia")
    estado = fields.Selection([
        ('PA', 'Pendiente de Asignar'),
        ('AS', 'Asignado'),
        ('FI', 'Finalizado'),
        ('IN', 'Incidencia'),
        ('FA', 'Facturado'),
        ('CA', 'Cancelado')
    ], string="Estado", compute="_get_stage_id", required=True, default='PA', readonly=True, store=True)
    has_finished = fields.Boolean('Finalizado?', default=False)
    horarealizar = fields.Datetime(string='Hora Realización', required=True, readonly=False, select=True,
                                   default=fields.Datetime.now)
    
    def getR(self, type_):
        if type_ == 'r':
            return self.env.ref('gestion_envios.servicio_recogida').id
        
    def getMercanc(self):
        return self.env.ref('gestion_envios.mercancia_do').id

    tiposervicio = fields.Many2one("gestiondeenvios.servicio", string="Servicio", default=lambda self:self.getR('r'))
    tipomercancia = fields.Many2one("gestiondeenvios.mercancia", string="Mercancia", default=lambda self:self.getMercanc())
    tipopeso = fields.Boolean(related="tipomercancia.preguntarpeso")
    tipomedidas = fields.Boolean(related="tipomercancia.preguntarmedidas")
    contacts_partner_ids = fields.Many2many('res.partner', string='Contactos del partner',compute='_compute_contacts')
    contacto = fields.Many2one("res.partner", string="Nombre de Contacto")

    @api.depends('partner_id')
    def _compute_contacts(self):
        contact_ids = []
        for rec in self:
            if rec.partner_id:
                contact_ids = rec.partner_id.child_ids.filtered(lambda x: x.type == 'contact' and x.is_company == False).ids
            rec.contacts_partner_ids = [(6, 0, contact_ids)]
            
    @api.constrains('tipomercancia', 'bult_lines')
    def validate_fields(self):
        for rec in self:
            lines = rec.bult_lines
            if rec.tipomercancia.preguntarpeso:
                if not all(line.peso for line in lines) or any(line.peso < 1 for line in lines):
                    raise UserError("El campo peso debe ser positivo.")
            if rec.tipomercancia.preguntarmedidas:
                #if not rec.alto or not rec.ancho or not rec.fondo or rec.alto <= 0 or rec.ancho <= 0 or rec.fondo <= 0:
                if not all(line.alto for line in lines) or any(line.alto < 1 for line in lines) or \
                    not all(line.ancho for line in lines) or any(line.ancho < 1 for line in lines) or \
                    not all(line.fondo for line in lines) or any(line.fondo < 1 for line in lines):
                    raise UserError("Los campos largo-ancho-fondo deben ser positivos.")

    street = fields.Char(related="contacto.street", readonly=True)
    street2 = fields.Char(related="contacto.street2", readonly=True)
    city = fields.Char(related="contacto.city", readonly=True)
    state_id = fields.Many2one("res.country.state", related="contacto.state_id", string='State', ondelete='restrict',
                               readonly=True)
    zip = fields.Char(related="contacto.zip", readonly=True)
    country_id = fields.Many2one('res.country', related="contacto.country_id", string='Country', ondelete='restrict',
                                 readonly=True)

    nbultos = fields.Integer(string="Nº Bultos", store=True, compute="_compute_nbultos", default=0)
    
    move_many = fields.Boolean("Permitir movimiento masivo?", default=True)
    move_ref = fields.Char("Referencia")

    @api.onchange('referencias')
    def onchange_product_id(self):
        if self.intermedio_id.pricelist_id:
            product_ids = self.env['product.pricelist.item'].search(
                [('pricelist_id', '=', self.intermedio_id.pricelist_id.id)])
            return {'domain': {'referencias': [('product_tmpl_id', 'in', product_ids.mapped('product_tmpl_id').ids)]}}

    referencias = fields.Many2many(
        'product.product',
        'rel_envios_referencias',  # Nombre de la tabla de relación
        'envio_id',  # Columna para el modelo actual
        'referencia_id',  # Columna para el modelo relacionado
        string='Referencias',
        domain=[('sale_ok', '=', True)],
        change_default=True,
        ondelete='restrict',
    )

    product_id = fields.Many2many(
        'product.product',
        'rel_envios_productos',  # Nombre diferente para la tabla de relación
        'envio_id',  # Columna para el modelo actual
        'producto_id',  # Columna para el modelo relacionado
        string='Productos'
    )

    cantidad = fields.Float(digits=(6, 2), string="Cantidad", default=1)
    ref_ids = fields.One2many('ref.lines', 'inter_id', string="Referencias")

    precio = fields.Float(digits=(6, 2), string="Precio Unitario", default=0, store=True, compute="_compute_price")
    nota = fields.Text(string="Notas de la Tarea")

    team_id = fields.Many2one('crm.team', string='Sales Channel', oldname='section_id',
                              default=lambda self: self.env['crm.team'].sudo()._get_default_team_id(
                                  user_id=self.env.uid),
                              index=True, track_visibility='onchange')
    stage_id = fields.Many2one('gestiondeenvios.stage', string='Asignación', track_visibility='onchange', index=True,
                               domain="['|', ('team_id', '=', False), ('team_id', '=', team_id)]",
                               group_expand='_read_group_stage_ids', default=1)

    stage_id_anterior = fields.Many2one('gestiondeenvios.stage', string="Asignación anterior",
                                        compute="_get_stage_anterior", store=True)
    stage_id_nuevo = fields.Many2one('gestiondeenvios.stage', string="Asignación anterior", compute="_get_stage_nuevo",
                                     store=True)
    @api.depends('bult_lines')
    def _compute_nbultos(self):
        for rec in self:
            rec.nbultos = sum(line.quantity for line in rec.bult_lines)
    
    @api.constrains('nbultos')
    def val_cantidad(self):
        for rec in self:
            if (rec.tipopeso == True or rec.tipomedidas == True) and (not rec.nbultos or rec.nbultos < 1):
                raise UserError('No has agregado bultos. Agrega o cambia de Mercancìa.')

    @api.depends('stage_id')
    def _get_stage_anterior(self):
        for intermedio in self:
            intermedio.stage_id_anterior = intermedio.stage_id_nuevo

    @api.depends('stage_id_anterior')
    def _get_stage_nuevo(self):
        for intermedio in self:
            intermedio.stage_id_nuevo = intermedio.stage_id

    invoice_status = fields.Selection([
        ('upselling', 'Upselling Opportunity'),
        ('invoiced', 'Fully Invoiced'),
        ('to invoice', 'To Invoice'),
        ('no', 'Nothing to Invoice')
    ], string='Invoice Status', related='intermedio_id.invoice_status', store=True, readonly=True)

    state = fields.Selection([
        ('draft', 'Quotation'),
        ('sent', 'Quotation Sent'),
        ('sale', 'Sales Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled'),
    ], string='Proceso', compute="_compute_state", readonly=True, copy=False, index=True, track_visibility='onchange',
        default='draft')

    realizadopor = fields.Many2one('hr.employee', string="Realizado por", compute="_depends_get_id", readonly=True,
                                   store=True)
    horarealizado = fields.Datetime(string="Hora realizado", compute="_onchange_get_id", store=True, default="")

    realizadopornew = fields.Many2one('hr.employee', string="Mensajero actual", compute="_onchange_get_id",
                                      readonly=True,
                                      store=True, default=False)

    sequence = fields.Integer(string='Sequence', index=True, default=10)
    pricelist_id = fields.Many2one('product.pricelist', related="intermedio_id.pricelist_id")

    @api.depends('ref_ids.subtotal', 'ref_ids.price_tax', 'ref_ids.total')
    def _compute_price(self):
        for record in self:
            record.precio = sum(line for line in record.ref_ids.mapped('unit_price'))
            record.price_subtotal = sum(line for line in record.ref_ids.mapped('subtotal'))
            record.price_tax = sum(line for line in record.ref_ids.mapped('price_tax'))
            record.price_total = sum(line for line in record.ref_ids.mapped('total'))

    def _get_display_price(self, product):
        # TO DO: move me in master/saas-16 on saleorder
        if self.intermedio_id.pricelist_id.discount_policy == 'with_discount':
            price1 = self.env['product.pricelist'].sudo()._get_products_price([product], self.nbultos)
            #price = price1.get('<NewId origin=' + str(product.id) + ">")
            price = [value for key, value in price1.items()]

            logging.info(f"\n\n<<<<< product: {product.name} - price: {str(price)}  - nice price: {price1}")
            return price[0]
        product_context = dict(self.env.context, partner_id=self.intermedio_id.partner_id.id,
                               date=self.intermedio_id.date_order,
                               uom=self.product_uom.id)
        final_price, rule_id = self.intermedio_id.pricelist_id.with_context(product_context).get_product_price_rule(
            self.product_id, self.product_uom_qty or 1.0, self.intermedio_id.partner_id)
        base_price, currency_id = self.with_context(product_context)._get_real_price_currency(product, rule_id,
                                                                                              self.product_uom_qty,
                                                                                              self.product_uom,
                                                                                              self.intermedio_id.pricelist_id.id)
        if currency_id != self.intermedio_id.pricelist_id.currency_id.id:
            base_price = self.env['res.currency'].browse(currency_id).with_context(product_context).compute(base_price,
                                                                                                            self.intermedio_id.pricelist_id.currency_id)
        # negative discounts (= surcharge) are included in the display price
        return max(base_price, final_price)


    @api.constrains('precio')
    def _check_precio(self):
        precio_acum = 0.0
        for intermedio in self:
            for product in intermedio.referencias:
                precio = 0.0
                if self.intermedio_id.pricelist_id and self.intermedio_id.partner_id:
                    precio = self.env['account.tax']._fix_tax_included_price_company(
                        self._get_display_price(product), product.taxes_id, product.taxes_id,
                        self.intermedio_id.company_id)
                precio_acum += precio
            if len(self.product_id) > 1 and '{:.2f}'.format(precio_acum) != '{:.2f}'.format(self.precio):
                raise ValidationError(
                    "No puedes edtar el precio unitario en una linea con 2 o más referencias. El precio real: %s y el precio nuevo: %s" % (
                    precio_acum, self.precio))

    price_subtotal = fields.Float(compute='_compute_price', string='Subtotal', readonly=True, store=True)
    price_tax = fields.Float(compute='_compute_price', string='Taxes', readonly=True, store=True)
    price_total = fields.Float(compute='_compute_price', string='Total', readonly=True, store=True)

    #line_id = fields.One2many('gestiondeenvios.line', 'lineintermedio_id')

    # image: all image fields are base64 encoded and PIL-supported
    image = fields.Binary("Image", attachment=True,
                          help="This field holds the image used as avatar for this contact, limited to 1024x1024px", )
    image_medium = fields.Binary("Medium-sized image", attachment=True,
                                 help="Medium-sized image of this contact. It is automatically " \
                                      "resized as a 128x128px image, with aspect ratio preserved. " \
                                      "Use this field in form views or some kanban views.")
    image_small = fields.Binary("Small-sized image", attachment=True,
                                help="Small-sized image of this contact. It is automatically " \
                                     "resized as a 64x64px image, with aspect ratio preserved. " \
                                     "Use this field anywhere a small image is required.")

    @api.model
    def _get_default_image(self):
        img_path = get_module_resource('base', 'static/src/img', 'truck.png')
        if img_path:
            with open(img_path, 'rb') as f:
                image = f.read()

        return tools.image_resize_image_big(base64.b64encode(image))

    @api.constrains('stage_id')
    def _check_stage(self):
        for intermedio in self:
            logging.info(f"<<<<<<<<<<<<< validando stage_id {intermedio.stage_id.name}  --- estado: {intermedio.estado}")
            if intermedio.stage_id:
                if intermedio.stage_id.name == 'Finalizados' and intermedio.estado not in ['AS', 'FI', 'FA']:
                    raise exceptions.ValidationError(
                        "No se puede finalizar una tarea si no la ha realizado un mensajero")
                
                if intermedio.stage_id.name not in (
                'Finalizados', 'Finaliz. con Incidencias', 'Pendientes de asignar') and intermedio.has_finished:
                    raise exceptions.ValidationError(
                        "Esta tarea ya ha sido finalizada")

    @api.constrains('stage_id')
    def _check_stage_seq(self):
        seq_cont = 0
        now = datetime.now()
        five_minutes_ago = now - timedelta(minutes=1)
        inter = self.filtered(lambda x: x.stage_id.id == 1)
        intermedios_ordenados = sorted(inter, key=lambda x: x.create_date, reverse=True)
        for inter in intermedios_ordenados:
            logging.info(f"<<<<<<<< inter hora: {str(inter.create_date)}")
            inter.sequence = seq_cont
            seq_cont += 1
        
    def self_reload(self):
        return {'type': 'ir.actions.client', 'tag': 'soft_reload'}

    has_order = fields.Boolean('Ya tiene orden?', default=False)       
    @api.depends('stage_id', 'state')
    def _get_stage_id(self):
        for intermedio in self:
            if intermedio.stage_id:
                if intermedio.stage_id.name == "Pendientes de asignar":
                    intermedio.estado = 'PA'
                    intermedio.color = '#28A745'
                    intermedio.has_finished = False
                elif intermedio.stage_id.name == "Finalizados":
                    intermedio.estado = 'FI'
                    intermedio.color = '#6CE328'
                    intermedio.has_finished = True
                    self._prepare_sale_vals()
                elif intermedio.stage_id.name == "Finaliz. con Incidencias":
                    intermedio.estado = 'IN'
                else:
                    intermedio.estado = 'AS'
                if intermedio.invoice_status == 'invoiced':
                    intermedio.estado = 'FA'
                if intermedio.state == 'cancel':
                    intermedio.estado = 'CA'
                if intermedio.move_many and intermedio.move_ref:
                    self.env["gestiondeenvios.intermedio"].sudo().search([
                        ('move_ref', '=', intermedio.move_ref)
                    ]).write({'stage_id': intermedio.stage_id})
                    channel = "kanban_update"
                    message = {
                        "data": 'reload',
                        "channel": channel
                    }
                    self.env["bus.bus"].sudo()._sendone(channel, "notification", message)
                    
                    

    def _prepare_sale_vals(self):
        for record in self:        
            # Preparar las líneas de pedido
            order_lines = []
            for item in record.intermedio_id.gestiondeenvios_line.filtered(lambda x: not x.has_order):
                for ref in item.ref_ids:
                    order_lines.append((0, 0, {
                        'product_id': ref.product_id.id,
                        'product_uom_qty': ref.quantity,
                        'price_unit': ref.subtotal / ref.quantity,
                    }))

            # Preparar los valores del pedido de venta
            vals = {
                'partner_id': record.intermedio_id.partner_id.id,
                'origin': record.intermedio_id.name,
                'order_line': order_lines,  # Se pasan las líneas de pedido aquí
            }
            
            # Verificar si ya existe un pedido con el mismo origen, y si no, crear uno nuevo
            if not self.env['sale.order'].search([('origin', '=', record.intermedio_id.name)]):
                order = self.env['sale.order'].sudo().create(vals)
                #logging.info(f"<<<<<<<<<<<<<z order: {order.name} --- unit_price: {str(unit_price)}")
                
                # Asociar el pedido de venta al campo `sale_id` y cambiar el estado del intermedio
                record.intermedio_id.sale_id = order.id
                record.intermedio_id.state = 'done'
                order.action_confirm()
            # Marcar el registro como que ya tiene un pedido asociado
            record.has_order = True
    

    @api.onchange('tipomercancia')
    def rellenar_notas(self):
        for intermedio in self:
            intermedio.nota = intermedio.tipomercancia.plantillanotas

    @api.depends('intermedio_id.state')
    def _compute_state(self):
        for intermedio in self:
            intermedio.state = intermedio.intermedio_id.state

    @api.depends('stage_id')
    def _depends_get_id(self):
        for intermedio in self:
            if intermedio.stage_id:
                if (intermedio.stage_id.id <= 3 and intermedio.realizadopornew) or intermedio.stage_id.id > 3:
                    intermedio.realizadopor = intermedio.realizadopornew.id

    @api.depends('realizadopor')
    def _onchange_get_id(self):
        for intermedio in self:
            if intermedio.stage_id and intermedio.intermedio_id.tipoalbaran is False:
                if intermedio.stage_id.id > 3:
                    intermedio.realizadopornew = intermedio.stage_id.mensajerorelacionado.id
                else:
                    intermedio.realizadopornew = intermedio.realizadopor
                    if intermedio.stage_id.id in (2, 3):
                        intermedio.horarealizado = datetime.now()

            if intermedio.stage_id and intermedio.intermedio_id.tipoalbaran is True:
                if intermedio.stage_id.id > 3:
                    intermedio.realizadopornew = intermedio.stage_id.mensajerorelacionado.id
                    intermedio.horarealizado = intermedio.intermedio_id.datealbaran
                else:
                    intermedio.realizadopornew = intermedio.realizadopor
                    intermedio.horarealizado = intermedio.intermedio_id.datealbaran
    
    @api.model
    def create(self, vals):
        vals['move_ref'] = self.env["gestiondeenvios.clase"].sudo().browse(vals.get('intermedio_id')).cargo_expediente
        return super().create(vals)
    
    def unlink(self):
        if self.filtered(lambda x: x.state in ('sale', 'done')):
            raise UserError(
                _('No puedes eliminar una linea mientras el envio este en "Sales Order", "Locked"'))
        return super(Gestiondeenviosintermedio, self).unlink()

    @api.model
    def _read_group_stage_ids(self, stages, domain, order):
        # retrieve team_id from the context and write the domain
        # - ('id', 'in', stages.ids): add columns that should be present
        # - OR ('fold', '=', False): add default columns that are not folded
        # - OR ('team_ids', '=', team_id), ('fold', '=', False) if team_id: add team columns that are not folded
        team_id = self._context.get('default_team_id')
        if team_id:
            search_domain = [('asignarenvios', '=', True), '|', ('id', 'in', stages.ids), '|', ('team_id', '=', False),
                             ('team_id', '=', team_id)]
        else:
            search_domain = [('asignarenvios', '=', True), '|', ('id', 'in', stages.ids), ('team_id', '=', False)]

        # perform search
        stage_ids = stages._search(search_domain, order=order, access_rights_uid=SUPERUSER_ID)
        return stages.browse(stage_ids)

    @api.onchange('referencias')
    def _onchange_product_id(self):
        domain = {}
        if not self.intermedio_id:
            return

        part = self.intermedio_id.partner_id

        if not part:
            warning = {
                'title': 'Alerta!',
                'message': 'Primero debes seleccionar una empresa de facturación!',
            }
            return {'warning': warning}

        estatus = self.intermedio_id.invoice_status
        if estatus == 'invoiced':
            warning = {
                'title': 'Alerta!',
                'message': 'No se puede añadir una tarea, puesto que ya se ha facturado.',
            }
            return {'warning': warning}
        return

    def open_maps(self):
        self.ensure_one()  # Asegura que solo se esté tratando un registro
        location_url = self.contacto.location  # Obtiene la URL
        return {
            'type': 'ir.actions.act_url',
            'url': location_url,  # Usa la URL que obtuviste
            'target': 'new',  # Esto abre en una nueva ventana
        }
    
    def uncheck_item(self):
        logging.info(f"<<<<<<<<<<<<< item checked: {self.name}")
        ok = 0
        if self.move_many:
            for rec in self.env["gestiondeenvios.intermedio"].sudo().search([
                ('move_ref', '=', self.move_ref),
                ('id', '!=', self.id),
            ]):
                rec.move_many = False
                logging.info(f"<<<<<<<<<<<<< item to update: {rec.name}: {str(rec.id)}")
            self.move_many = False

        elif not self.move_many:
            for rec in self.env["gestiondeenvios.intermedio"].sudo().search([
                ('move_ref', '=', self.move_ref),
                ('id', '!=', self.id),
            ]):
                rec.move_many = True
                logging.info(f"<<<<<<<<<<<<< item to update: {rec.name}: {str(rec.id)}")
            self.move_many = True
    
    def open_ref(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'gestiondeenvios.clase',
            'view_mode': 'form',
            'view_type': 'form',
            'res_id': self.intermedio_id.id,
            'target': 'new',
        }
    
    def open_inter(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'gestiondeenvios.intermedio',
            'view_mode': 'form',
            'view_type': 'form',
            'res_id': self.id,
            'target': 'new',
        }
