from . import res_partner
from . import hr_employee
from . import res_settings
from . import account_move
from . import sale_order