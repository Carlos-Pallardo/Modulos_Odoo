from odoo import fields, http, _, SUPERUSER_ID
from odoo.http import request

class GestionEnvios(http.Controller):

    @http.route(['/gest_delivery_kanban'], type='http', auth="public")
    def render_kanbanview(self, **kw):
        return request.render('gestion_envios.kanban_template', {})